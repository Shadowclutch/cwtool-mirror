-- 527040's Lua and Manifest Created by Hubcap Manifest
--  Armies of Riddle CLASSIC
-- Created: October 02, 2025 at 07:03:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(527040) --  Armies of Riddle CLASSIC
-- MAIN APP DEPOTS
addappid(527041, 1, "eb3dcb9cf5f8e8b16aa140c81d6befcd4f247bee180f1d602e090073ab7c6a50") -- Armies of Riddle CCG Fantasy Battle Card Game Content
setManifestid(527041, "1041859720990709856", 294278410)