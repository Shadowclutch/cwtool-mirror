-- 2848190's Lua and Manifest Created by Hubcap Manifest
-- Population Goals!
-- Created: July 10, 2026 at 16:41:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2848190) -- Population Goals!
-- MAIN APP DEPOTS
addappid(2848191, 1, "4ffa2c045ab5efcf902b3a0d3804acc7364075961c8fa83dce50c66cc22300ce") -- Depot 2848191
setManifestid(2848191, "8948252832997556578", 247063543)