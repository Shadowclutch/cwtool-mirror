-- 2003990's Lua and Manifest Created by Hubcap Manifest
--  Arcade Sundown
-- Created: October 02, 2025 at 04:58:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2003990) --  Arcade Sundown
-- MAIN APP DEPOTS
addappid(2003991, 1, "6f45f60863a356d819a3862c5a44e1dbb120d43feacd48355f74bb87d6cc3731") -- Depot 2003991
setManifestid(2003991, "5229500424594399776", 1951044182)