-- 5254's Lua and Manifest Created by Hubcap Manifest
-- Call of Duty: World at War - Verruckt
-- Created: July 05, 2026 at 00:16:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5254) -- Call of Duty: World at War - Verruckt
-- MAIN APP DEPOTS
addappid(910, 1, "168405455442eaf4e8e75a13b5914f35d7be54b0cdc4220ea1dc464f79711248") -- Media Player
setManifestid(910, "1332084816209327708", 266240)