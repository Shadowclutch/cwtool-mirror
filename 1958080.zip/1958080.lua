-- 1958080's Lua and Manifest Created by Hubcap Manifest
-- Aqua Populo Demo
-- Created: July 10, 2026 at 20:13:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1958080) -- Aqua Populo Demo
-- MAIN APP DEPOTS
addappid(1958081, 1, "1f237aad8fa48f8686dee4d138d9de6b978d8a6d0dc8f5c990c43fa8de7fed58") -- Depot 1958081
setManifestid(1958081, "7858363789149415956", 257)
addappid(1958082, 1, "4b0b0f92bffa32506fc2f70b9262222637ec5f6bed32d466632b8339b8cba713") -- Depot 1958082
setManifestid(1958082, "2701723084182672945", 92422513)
addappid(1958083, 1, "7a8f9ef9c9adb361c1ade814fbdafa06de9d5eb6ee4ddfc4a817a580f7e51c3d") -- Depot 1958083
setManifestid(1958083, "2903918302908175162", 105797286)