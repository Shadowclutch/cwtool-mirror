-- 730's Lua and Manifest Created by Hubcap Manifest
-- Counter-Strike 2
-- Created: July 28, 2026 at 20:50:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 16
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(730, 1, "2e61570111ad4d1e4abcb711576f96b84907a024f9f9bf4a4d692d7c132ee91b") -- Counter-Strike 2
-- MAIN APP DEPOTS
addappid(732, 1, "da1f76913633e9ce1b2bda5ec464dc507205388fac5c4c614b6a2706cdbd0912") -- Counter-Strike Global Offensive Beta Win Bin
setManifestid(732, "8865603041742505094", 8)
addappid(733, 1, "23c8e9a91561a5fb08abf22f2ac98929f4aad68a12164268d3b2800c3db4fb03") -- Counter-Strike Global Offensive Beta Mac Bin
setManifestid(733, "5948035287505683606", 8)
addappid(731, 1, "bca9a9cde94bb4dff61849c6a87230ee45867a590fdd28826366e35e7d62c08e") -- Counter-Strike Global Offensive Beta Common
setManifestid(731, "2177642409584128815", 8)
addappid(734, 1, "54fd243c5463c16ec7d32b5b4c7b792b3f2d3f75009ac3e81135ff999b56187f") -- Counter-Strike: Global Offensive Beta Linux Bin
setManifestid(734, "554806932236036384", 8)
addappid(735, 1, "a0ef69f0cf8abd70aa9ed79755fbe4d98cf7c6723ba9e0c66e0f7102e49541e6") -- Counter-Strike: Global Offensive (General)
setManifestid(735, "5985333859037771963", 8)
addappid(736, 1, "e81988c241b4ec9fc7fe1ab34697689f131a48c78da95c985ed347fb43bdc6de") -- Counter-Strike: Global Offensive (Perfect World)
setManifestid(736, "2564487739876505594", 8)
addappid(737, 1, "c80f96efa325374c18c6d5d63ccd2687b1680a908c6def5c5c808e695f1ddbf9") -- Counter-Strike: Global Offensive (Perfect World Assets)
setManifestid(737, "5114115648805693971", 8)
addappid(738, 1, "fbc1a292c9b75e33512ed82476267efbf34f1ed1b177651ed8b091cf7174d183") -- Counter-Strike: Global Offensive (Chinese Voice Audio)
setManifestid(738, "7957225838203103176", 8)
addappid(2347770, 1, "b23a737920b6a72f932a5bcdbdf51770d7d4d394a13f95b1cf29db28c1043d88") -- Depot 2347770
setManifestid(2347770, "7357001356549703767", 62784439847)
addappid(2347771, 1, "b80e2b4bd2a244ba996a013850b5d2f46c897f382164181b382c5d672fcb5090") -- Depot 2347771
setManifestid(2347771, "5814144478477689230", 7662613561)
addappid(2347772, 1, "7938abf64ef719e6414d5e385f90ccbef9c6a2c21ab42b471a09641d2b2ba32f") -- Depot 2347772
setManifestid(2347772, "4427303554736365309", 9276)
addappid(2347773, 1, "d030f2b7078446257db4b4decd86a38b0ae3816b4847a04e609277e20f25d5d7") -- Depot 2347773
setManifestid(2347773, "56114211749641557", 7172639353)
addappid(2347774, 1, "71e79678830ea0234437b03526e2ede2decfed847ce20bae413718b47db44bea") -- Depot 2347774
setManifestid(2347774, "6880616264887178762", 1142056124)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Counter-Strike 2 Workshop Tools (AppID: 2279721)
addappid(2279721)
addtoken(2279721, "13110678024753570950")
addappid(2347779, 1, "a3d6504606875447dc6dedcba78bebb3e0a122fb30a504ef805536f216354271") -- Counter-Strike 2 Workshop Tools - Counter-Strike 2 Workshop Tools
setManifestid(2347779, "2354482487203280838", 2091723547)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1490530) -- Counter-Strike Global Offensive - Operation Broken Fang
addappid(1766730) -- CSGO - Operation Riptide
addappid(2279720) -- Counter-Strike 2 (Limited Test)
addtoken(2279720, "1473763366698117373")
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2347775) -- Depot 2347775 (empty depot)
-- addappid(2347776) -- Depot 2347776 (empty depot)
-- addappid(2347778) -- Depot 2347778 (empty depot)